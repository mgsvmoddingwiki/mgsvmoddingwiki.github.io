local this = {}
    this.missionCode = 13000
    this.location = "AFGH"
    this.hideMission = false

    this.packs = function(missionCode)
        --Common packs:
        TppPackList.AddLocationCommonScriptPack(missionCode)
        TppPackList.AddLocationCommonMissionAreaPack(missionCode)

        --Mission pack (has to be last):
        TppPackList.AddMissionPack"/Assets/tpp/pack/mission2/custom_story/s13000/FPK_Name_Example.fpk"--The mission's core "area" pack
    end

    this.missionGuaranteeGMP=600000

    this.enableOOB = true --Enable out of bounds system (innerZone, outerZone, hotZone)
    this.missionMapParams={
        --Normal mission area zones as they appear on the iDroid
        --The actual in-game check traps are in .trap files.
        missionArea2 = {
            --Leaving the innerZone will only warn the player that they're leaving
            {
                name="trig_innerZone",
                vertices =
                {
                    Vector3(-58.000,315.000,1764.000),
                    Vector3(-238.000,321.000,2445.000),
                    Vector3(768.000,289.000,2486.000),
                    Vector3(653.000,353.000,1824.000),

                }
            }
            --Leaving the outerZone will actually trigger the mission clear/abort
            --Commented out as it will be be displayed alongside the innerZone otherwise
            --[[
            {
				name="trig_outerZone",
            	--.trap only:
				--minY=-213.1406,maxY=1299.037,
                vertices =
                { 
                    Vector3(-58.000,315.000,1764.000),
                    Vector3(-238.000,321.000,2445.000),
                    Vector3(768.000,289.000,2486.000),
                    Vector3(653.000,353.000,1824.000),

                } 
			},
			]]
        },
		--Hot zone as it appears on the iDroid
        safetyArea2 = {
			{
				name="trig_hotZone",
				vertices =
				{
                    Vector3(-58.000,315.000,1764.000),
                    Vector3(-238.000,321.000,2445.000),
                    Vector3(768.000,289.000,2486.000),
                    Vector3(653.000,353.000,1824.000),

				},
			},
		},
        missionStartPoint = {
            point = Vector3(141.47,275.51,2353.44),
		},
        heliLandPoint = {
    		{
                point=Vector3(418.33,278.22,2261.37),startPoint=Vector3(418.33,278.22,2261.37),routeId="lz_drp_field_I0000|rt_drp_field_I_0000"
            },
            {
                point=Vector3(141.47,275.51,2353.44),startPoint=Vector3(141.47,275.51,2353.44),routeId="lz_drp_fieldWest_S0000|rt_drp_fiieldWest_S_0000"
            },

		},
        -- Sortie/mission prep screen feature flags
        heliSpaceFlags = {
    		SkipMissionPreparetion = false,   --No sortie prep, like vanilla Mother Base.
    		NoBuddyMenuFromMissionPreparetion = false,    -- No buddy select in the sortie
   			NoVehicleMenuFromMissionPreparetion = false,    -- No vehicle select in the sortie
    		DisableSelectSortieTimeFromMissionPreparetion = false,    -- Only ASAP as deployment time option
  		},
    }


return this